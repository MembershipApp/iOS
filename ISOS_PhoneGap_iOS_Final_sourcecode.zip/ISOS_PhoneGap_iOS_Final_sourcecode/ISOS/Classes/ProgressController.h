//
//  ProgressController.h
//  AdaptiveMobile
//
//  Created by AdaptiveMobile Security Ltd.
//  Copyright 2012 AdaptiveMobile Security Ltd. All rights reserved.
//

//Creates progress bar view.
@interface ProgressController : NSObject 
{
	UIView* progressScreen;
	NSString *progressString;
}

@property(retain, readwrite) NSString *progressString;

-(void)startProgressBar;
-(void) removeProgressBar;
@end
